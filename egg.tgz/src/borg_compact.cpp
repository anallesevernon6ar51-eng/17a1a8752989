// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Compact repository"); }
int main(){
  announce();
  return lionss_run_workload("borg_compact");
}
